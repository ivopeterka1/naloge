﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pretvori_enote
{
    public partial class Form1 : Form
    {
        private bool programsko = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void izvediPretvorbo(object sender, EventArgs e)
        {
            if (vnosCm.Text == "")
            {
                if (vnosMm.Text == string.Empty)
                {
                    throw new ArgumentException("Obe polji sta prazni");
                }
                vnosCm.Text = (int.Parse(vnosMm.Text) / 10).ToString();
            }
            else
            {
                vnosMm.Text = (int.Parse(vnosCm.Text) * 10).ToString();

            }
        }

        private void vnosMm_TextChanged(object sender, EventArgs e)
        {
            if (!programsko)
            {
                programsko = true;
                vnosCm.Text = string.Empty;
                programsko = false;
            }
        }

        private void vnosCm_TextChanged(object sender, EventArgs e)
        {
            if (!programsko)
            {
                programsko = true;
                vnosMm.Text = string.Empty;
                programsko = false;
            }
        }
    }
}
