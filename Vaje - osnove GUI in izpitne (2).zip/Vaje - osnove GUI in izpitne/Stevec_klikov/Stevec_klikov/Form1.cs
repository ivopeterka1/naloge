﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stevec_klikov
{
    public partial class Form1 : Form
    {
        int klik;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            klik++;
            label1.Text = "Stevec klikov: " + klik;
        }
    }
}
