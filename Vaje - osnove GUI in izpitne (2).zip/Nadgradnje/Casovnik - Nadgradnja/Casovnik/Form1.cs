﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Casovnik
{
    public partial class Form1 : Form
    {
        private double timeElapsed = 0.0;
        private bool isRunning = false;

        public Form1()
        {
            InitializeComponent();
            timer1.Interval = 100; // Timer tick every 100 ms
            timer1.Tick += timer1_Tick;
            button1.Text = "Start/Stop";
            label1.Text = "0.0s";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (isRunning)
            {
                timeElapsed += 0.1;
                label1.Text = $"{timeElapsed:F1}s";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            isRunning = !isRunning;
            if (isRunning)
            {
                timer1.Start();
                button1.Text = "Stop";
            }
            else
            {
                timer1.Stop();
                button1.Text = "Start";
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            // Ponastavitev štoparice in časa na zaslonu
            timer1.Stop();  // Ustavitev timerja, če je aktiven
            timeElapsed = 0;  // Ponastavitev merjenega časa
            label1.Text = "0.0s";  // Ponastavitev prikaza časa na 0.0 sekund
        }
    
    }
}
