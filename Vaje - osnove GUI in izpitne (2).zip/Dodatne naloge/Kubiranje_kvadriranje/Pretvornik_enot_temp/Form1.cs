﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pretvornik_enot_temp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Preberemo vrednost iz TextBoxa
            if (double.TryParse(textBox1.Text, out double number))
            {
                // Izračunamo kubiranje vnosa
                double result = Math.Pow(number, 3);
                // Prikaz rezultata
                MessageBox.Show($"Kubik števila {number} je {result}.", "Rezultat");
            }
            else
            {
                MessageBox.Show("Vnesite veljavno številko.", "Napaka");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out double number))
            {
                // Izračunamo kubiranje vnosa
                double result = Math.Pow(number, 2);
                // Prikaz rezultata
                MessageBox.Show($"Kvadrat števila {number} je {result}.", "Rezultat");
            }
            else
            {
                MessageBox.Show("Vnesite veljavno številko.", "Napaka");
            }
        }
    }
}
